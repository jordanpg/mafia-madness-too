exec("./gui/main.cs");

exec("./startGame.cs");