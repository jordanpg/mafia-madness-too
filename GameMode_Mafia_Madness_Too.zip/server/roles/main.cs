if(!$MM::LoadedRole)
	exec($MM::Server @ "MM_Role.cs");

exec("./innocent.cs");
exec("./mafia.cs");

exec("./abductor.cs");
exec("./alarmist.cs");
exec("./amnesiac.cs");
exec("./boomguy.cs");
exec("./bubbleBuddy.cs");
exec("./clown.cs");
exec("./cop.cs");
exec("./cop_variants.cs");
exec("./crazy.cs");
exec("./cultist.cs");
exec("./devil.cs");
exec("./fingerprintExpert.cs");
exec("./godfather.cs");
exec("./jester.cs");
exec("./johnCena.cs");
exec("./miller.cs");
exec("./reviverCultist.cs");
exec("./spy.cs");
exec("./cultSpy.cs");
exec("./theLaw.cs");
// exec("./traitor.cs");
exec("./ventriloquist.cs");