exec("./Colt Python.cs");
exec("./Magnum Research.cs");
exec("./Snubnose.cs");
exec("./Tanaka Works.cs");

exec("./Silent Combat Knife.cs");